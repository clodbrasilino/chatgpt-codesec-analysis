#include <stdio.h>
#include <math.h>

#define PI 3.14159265

double calculate_lateral_surface_area(double radius, double height) {
    if(radius < 0 || height < 0) {
        return -1;
    }
    double slantHeight = sqrt((radius * radius) + (height * height));
    return PI * radius * slantHeight;
}

int main() {
    double radius, height;

    printf("Enter the radius of the cone: ");
    scanf("%lf", &radius);

    printf("Enter the height of the cone: ");
    scanf("%lf", &height);

    double area = calculate_lateral_surface_area(radius, height);
    
    if(area < 0) {
        printf("Invalid input, please enter positive values for radius and height.\n");
        return -1;
    }

    printf("The lateral surface area of the cone is: %lf\n", area);

    return 0;
}