#include <stdio.h>
#include <stdbool.h>

bool isInfiniteSequence(int num){
    if(num >= 0 && num%3 == 0) {
        return true;
    }
    return false;
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    if(isInfiniteSequence(num)){
        printf("%d is present in the infinite sequence.\n", num);
    } else {
        printf("%d is not present in the infinite sequence.\n", num);
    }
    return 0;
}