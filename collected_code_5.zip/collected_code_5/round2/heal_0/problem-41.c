#include <stdio.h>

void filter_even_numbers(int arr[], int size) {
    int i;
    
    for(i = 0; i < size; i++) {
        if(arr[i] % 2 == 0) 
            printf("%d ", arr[i]);
    }
}

int main() {
    int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int size = sizeof(arr) / sizeof(arr[0]);

    printf("Even numbers in the array are: ");
    filter_even_numbers(arr, size);
    
    return 0;
}