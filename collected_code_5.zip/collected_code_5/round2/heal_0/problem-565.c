#include <stdio.h>
#include <string.h>

void split_string_into_chars(char *str) {
    int length = strlen(str);
    for(int i = 0; i < length; i++) {
        printf("%c ", str[i]);
    }
    printf("\n");
}

int main() {
    char str[100];
    printf("Enter a string: ");
    fgets(str, sizeof str, stdin);

    str[strcspn(str, "\n")] = 0;

    split_string_into_chars(str);

    return 0;
}