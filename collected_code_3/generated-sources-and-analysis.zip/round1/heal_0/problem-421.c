#include <stdio.h>
#include <string.h>

#define MAX_SIZE 100

char* concatenateTuple(char tuple[][MAX_SIZE], int size, char delimiter[]) {
    static char result[MAX_SIZE];
    strcpy(result, tuple[0]);

    for(int i = 1; i < size; i++) {
        strcat(result, delimiter);
        strcat(result, tuple[i]);
    }

    return result;
}

int main() {
    char tuple[3][MAX_SIZE] = {"Hello", "World", "!"};
    char delimiter[] = " ";

    char* result = concatenateTuple(tuple, 3, delimiter);

    printf("%s\n", result);

    return 0;
}