#include <stdio.h>

int find_rotations(int arr[], int n) {
    int low = 0, high = n - 1;

    while (low <= high) {
        if (arr[low] <= arr[high])
            return low;
        
        int mid = low + (high - low) / 2;
        int next = (mid + 1) % n;
        int prev = (mid + n - 1) % n;
        
        if (arr[mid] <= arr[prev] && arr[mid] <= arr[next])
            return mid;
        else if (arr[mid] <= arr[high])
            high = mid - 1;
        else if (arr[mid] >= arr[low])
            low = mid + 1;
    }

    return -1;
}

int main() {
    int arr[] = {15, 22, 23, 28, 31, 38, 5, 6, 8, 10};
    int rotations = find_rotations(arr, 10);

    if (rotations != -1) {
        printf("The array is rotated %d times\n", rotations);
    } else {
        printf("The array is not rotated\n");
    }

    return 0;
}