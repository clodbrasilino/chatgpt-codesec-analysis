#include <stdio.h>
#include <stdlib.h>

int countDigits(int number){
    int count = 0;
    if(number == 0)
        return 1;
    while(number != 0){
        number = number / 10;
        ++count;
    }
    return count;
}

int main() {
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);
    printf("Number of digits: %d", countDigits(abs(number)));
    return 0;
}