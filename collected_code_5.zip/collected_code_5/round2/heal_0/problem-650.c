#include <stdio.h>
#include <stdbool.h>

bool areArrsEqual(int *arr1, int arr1_len, int *arr2, int arr2_len) {
    int i;

    /* If lengths of arrays are not equal */
    if (arr1_len != arr2_len)
        return false;

    /* To compare values of each element */
    for(i=0; i<arr1_len; i++) {
        if (arr1[i] != arr2[i])
            return false;
    }

    return true;
}

int main() {
    int arr1[] = {1, 2, 3, 4, 5};
    int arr2[] = {1, 2, 3, 4, 5};
    int arr1_len = sizeof(arr1) / sizeof(arr1[0]);
    int arr2_len = sizeof(arr2) / sizeof(arr2[0]);

    if (areArrsEqual(arr1, arr1_len, arr2, arr2_len)) 
        printf("The two arrays are equal\n");
    else 
        printf("The two arrays are not equal\n");

    return 0;
}