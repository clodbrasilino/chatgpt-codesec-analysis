#include <stdio.h>

int roundToNearestMultiple(int num, int multiple) {
    int remainder = num % multiple;
    if (remainder == 0)
        return num;
    return num + multiple - remainder;
}

int main() {
    int num, multiple;
    printf("Enter a number: ");
    scanf("%d", &num);
    printf("Enter the multiple to which you want to round off: ");
    scanf("%d", &multiple);
    printf("The rounded off number is: %d\n", roundToNearestMultiple(num, multiple));
    return 0;
}