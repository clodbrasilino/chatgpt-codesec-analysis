#include <stdio.h>

int getElement(int array[], int rotations, int size, int index) {
    if (array == NULL || size <= 0) {
        return -1;
    }

    if (index < 0 || index >= size) {
        return -1;
    }

    rotations %= size;

    if (rotations < 0) {
        rotations += size;
    }

    if (index >= rotations) 
        return array[index - rotations]; 
    else 
        return array[index - rotations + size];
}

int main() 
{
    int array[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int size = sizeof(array) / sizeof(array[0]);
    int rotations = 2;
    int index = 1;

    int result = getElement(array, rotations, size, index);

    if (result != -1) 
        printf("The element at index %d after %d rotations is %d\n", index, rotations, result);
    else 
        printf("Error occurred\n");

    return 0;
}