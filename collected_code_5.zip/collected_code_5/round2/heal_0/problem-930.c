#include <stdio.h>
#include <string.h>
#include <regex.h>

int match(const char *string) {
    regex_t regex;
    int reti;

    reti = regcomp(&regex, "a*b*", 0);
    if (reti) {
        fprintf(stderr, "Could not compile regex\n");
        return 0;
    }

    reti = regexec(&regex, string, 0, NULL, 0);
    if (!reti) {
        regfree(&regex);
        return 1;
    } else if (reti == REG_NOMATCH) {
        regfree(&regex);
        return 0;
    } else {
        char msgbuf[100];
        regerror(reti, &regex, msgbuf, sizeof(msgbuf));
        fprintf(stderr, "Regex match failed: %s\n", msgbuf);
        return 0;
    }
}

int main() {
    char *testString = "abb";
    int result = match(testString);

    if(result) {
        printf("String '%s' matches pattern\n", testString);
    } else {
        printf("String '%s' does not match pattern\n", testString);
    }

    return 0;
}