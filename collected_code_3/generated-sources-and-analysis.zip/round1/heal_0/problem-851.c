#include <stdio.h>
#include <math.h>

double sum_inverse_divisors(int n) {
    double sum = 0;
    for (int i = 1; i <= sqrt(n); i++) {
        if (n % i == 0) {
            if (n / i == i) {
                sum += 1.0 / i;
            } else {
                sum += 1.0 / i;
                sum += 1.0 / (n / i);
            }
        }
    }
    return sum;
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    printf("Sum of inverse of divisors: %.2f\n", sum_inverse_divisors(num));
    return 0;
}