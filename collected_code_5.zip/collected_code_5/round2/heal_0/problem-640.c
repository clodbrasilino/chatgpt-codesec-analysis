#include <stdio.h>
#include <string.h>

char *remove_parentheses(char *str) {
    
    static char result[1000];
    int record = 0;
    int j = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        if(str[i] == '(') {
            record++;
            continue;
        }
        else if(str[i] == ')') {
            if(record > 0) {
                record--;
            }
            continue;
        }

        if(record == 0) {
            result[j] = str[i];
            j++;
        }
    }
    result[j] = '\0';
    while(record > 0) {
        result[j] = ')';
        j++;
        record--;
    }
    result[j] = '\0';
    return result;
}

int main() {
    char str[] = "Hello, (World)!";
    printf("Original string: %s\n", str);
    printf("Modified string: %s\n", remove_parentheses(str));
    return 0;
}