#include <stdio.h>

float quotient(int num1, int num2) {
    return (float)num1 / num2;
}

int main() {
    int num1, num2;
    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);
    printf("Quotient: %.2f", quotient(num1, num2));
    return 0;
}