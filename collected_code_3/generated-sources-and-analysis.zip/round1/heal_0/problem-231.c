#include <stdio.h>
#define N 3

int maxSum(int tri[N][N]) {
    for (int i=N-1; i>=0; i--) {
        for (int j=0; j<=i; j++) {
            if (tri[i+1][j] > tri[i+1][j+1])
                tri[i][j] += tri[i+1][j];
            else
                tri[i][j] += tri[i+1][j+1];
        }
    }
    return tri[0][0];
}

int main() {
    int tri[N][N] = { {1, 0, 0},
                      {4, 8, 0},
                      {1, 5, 3} };
    printf("%d\n", maxSum(tri));
    return 0;
}