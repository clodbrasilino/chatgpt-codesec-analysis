#include <stdio.h>
#include <string.h>

void createPalindrome(char *str, int len) {
    int l = 0;
    int r = len - 1;
    while (l < r) {
        str[r] = str[l];
        l++;
        r--;
    }
}

int isAll9s(char* str, int len) {
    int i;
    for (i = 0; i < len; ++i)
        if (str[i] != '9')
            return 0;
    return 1;
}

void nextPalindrome(char *num, int len) {
    int mid = len / 2;
    int i = mid - 1;
    int j = (len % 2) ? mid + 1 : mid;
    int leftsmaller = 0;

    while (i >= 0 && num[i] == num[j])
        i--, j++;

    if (i < 0 || num[i] < num[j])
        leftsmaller = 1;

    while (i >= 0) {
        num[j] = num[i];
        j++;
        i--;
    }

    if (leftsmaller == 1) {
        int carry = 1;
        i = mid - 1;

        if (len % 2 == 1) {
            num[mid] += carry;
            carry = num[mid] / 10;
            num[mid] %= 10;
            j = mid + 1;
        }
        else
            j = mid;

        while (i >= 0) {
            num[i] += carry;
            carry = num[i] / 10;
            num[i] %= 10;
            num[j++] = num[i--];
        }
    }
}

void generateNextPalindrome(char *str, int len) {
    int i;

    if (isAll9s(str, len)) {
        printf("1");
        for (i = 1; i < len; i++)
            printf("0");
        printf("1");
    }
    else {
        nextPalindrome(str, len);
        printf("%s", str);
    }
}

int main() {
    char num[100];
    printf("Enter a number: ");
    scanf("%s", num);
    int len = strlen(num);
    generateNextPalindrome(num, len);
    return 0;
}