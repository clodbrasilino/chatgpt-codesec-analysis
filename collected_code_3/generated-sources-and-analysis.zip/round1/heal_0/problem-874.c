#include <stdio.h>
#include <string.h>

int isConcatenation(char *str1, char *str2) {
    int len1 = strlen(str1);
    int len2 = strlen(str2);

    if(len1 % len2 != 0) {
        return 0;
    }

    for(int i = 0; i < len1; i += len2) {
        if(strncmp(str1 + i, str2, len2) != 0) {
            return 0;
        }
    }

    return 1;
}

int main() {
    char str1[100], str2[100];

    printf("Enter first string: ");
    scanf("%s", str1);

    printf("Enter second string: ");
    scanf("%s", str2);

    if(isConcatenation(str1, str2)) {
        printf("The first string is a concatenation of the second string.\n");
    } else {
        printf("The first string is not a concatenation of the second string.\n");
    }

    return 0;
}