#include <stdio.h>
#include <stdbool.h>

#define ARRAY_SIZE(arr) sizeof(arr) / sizeof(arr[0])

bool are_consecutive(int arr[], int n) {
    int min = arr[0];
    int max = arr[0];

    for (int i = 1; i < n; i++) {
        if (arr[i] < min)
            min = arr[i];
        if (arr[i] > max)
            max = arr[i];
    }

    if (max - min + 1 == n) {
        bool visited[n];
        for (int i = 0; i < n; i++)
            visited[i] = false;

        for (int i = 0; i < n; i++) {
            if (visited[arr[i] - min] != false)
                return false;
            visited[arr[i] - min] = true;
        }

        return true;
    }
    return false;
}

int main() {
    int arr1[] = {5, 2, 3, 1, 4};
    int array_size = ARRAY_SIZE(arr1);
    bool result = are_consecutive(arr1, array_size);
    if (result == true) {
        printf("The array elements are consecutive\n");
    } else {
        printf("The array elements are not consecutive\n");
    }

    return 0;
}