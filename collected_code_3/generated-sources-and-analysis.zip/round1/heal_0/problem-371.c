#include <stdio.h>

int findSmallestMissing(int array[], int start, int end) {
    if (start > end)
        return end + 1;

    if (start != array[start])
        return start;

    int mid = (start + end) / 2;

    if (array[mid] == mid)
        return findSmallestMissing(array, mid+1, end);

    return findSmallestMissing(array, start, mid);
}

int main() {
    int array[] = {0, 1, 2, 3, 4, 5, 6, 7, 10};
    int n = sizeof(array) / sizeof(int);
    printf("Smallest missing element is %d", findSmallestMissing(array, 0, n-1));
    return 0;
}