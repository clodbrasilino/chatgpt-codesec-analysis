#include <stdio.h>

void is_scalene(int a, int b, int c) {
    if (a <= 0 || b <= 0 || c <= 0) {
        printf("Sides of a triangle can not be less than or equal to zero\n");
        return;
    }

    if(a != b && b != c && c != a) {
        printf("Triangle is scalene\n");
    } else {
        printf("Triangle is not scalene\n");
    }    
}

int main() {
    int a, b, c;
    printf("Enter the sides of the triangle : ");
    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%d", &c);

    is_scalene(a,b,c);

    return 0;
} 