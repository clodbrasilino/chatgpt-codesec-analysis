#include <stdio.h>

int findMax(int arr[], int low, int high) {
    if (high < low) 
        return arr[0];
    if (high == low) 
        return arr[low];
    int mid = low + (high - low)/2; 
    if (mid < high && arr[mid+1] < arr[mid])
        return arr[mid];
    if (mid > low && arr[mid] < arr[mid - 1])
        return arr[mid-1];
    if (arr[high] > arr[mid])
        return findMax(arr, low, mid-1);
    return findMax(arr, mid+1, high);
}

int main() {
    int arr[] = {5, 6, 1, 2, 3, 4};
    int n = sizeof(arr)/sizeof(arr[0]);
    printf("The maximum element is %d", findMax(arr, 0, n-1));
    return 0;
}