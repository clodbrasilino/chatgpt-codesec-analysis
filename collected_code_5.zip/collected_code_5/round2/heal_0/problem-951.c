#include <stdlib.h>
#include <stdio.h>

#define LIST_SIZE 5

typedef struct {
    int x;
    int y;
} Tuple;

int max_of_similar_indices(Tuple *list1, Tuple *list2, int size) {
    int max = -1;

    for (int i = 0; i < size; ++i) {
        if (list1[i].x == list2[i].x && list1[i].y == list2[i].y) {
            if (list1[i].x > max) {
                max = list1[i].x;
            }
            
            if (list1[i].y > max) {
                max = list1[i].y;
            }
        }
    }

    return max;
}

int main() {
    Tuple list1[LIST_SIZE] = {{5, 8}, {2, 4}, {3, 1}, {5, 2}, {3, 9}};
    Tuple list2[LIST_SIZE] = {{5, 9}, {3, 1}, {4, 6}, {5, 2}, {7, 9}};

    int result = max_of_similar_indices(list1, list2, LIST_SIZE);
    if (result == -1) {
        printf("There are no similar indices.");
    } else {
        printf("The maximum element at similar indices is %d.", result);
    }

    return 0;
}