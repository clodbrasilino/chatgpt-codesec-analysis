#include <stdio.h>
#include <string.h>

int countSubstr(char str[]) {
    int result = 0;
    int n = strlen(str);

    for (int i = 0; i < n; i++)
        for (int j = i; j < n; j++)
            if (str[i] == str[j])
                result++;

    return result;
}

int main() {
    char str[] = "abcab";
    printf("%d", countSubstr(str));
    return 0;
}